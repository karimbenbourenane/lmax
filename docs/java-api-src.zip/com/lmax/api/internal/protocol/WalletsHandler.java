package com.lmax.api.internal.protocol;

import com.lmax.api.FixedPointNumber;
import java.util.HashMap;
import java.util.Map;

import org.xml.sax.SAXException;

public class WalletsHandler extends MapBasedHandler
{
    private static final String WALLETS = "wallets";
    private static final String WALLET = "wallet";
    private static final String CURRENCY = "currency";
    private static final String BALANCE = "balance";

    private Map<String, FixedPointNumber> wallets = new HashMap<String, FixedPointNumber>();

    public WalletsHandler()
    {
        super(WALLETS);
        addHandler(new Handler(CURRENCY));
        addHandler(new Handler(BALANCE));
    }

    @Override
    public void endElement(final String localName) throws SAXException
    {
        if (WALLET.equals(localName))
        {
            wallets.put(getStringValue(CURRENCY), getFixedPointNumberValue(BALANCE));
        }
    }

    public void clear()
    {
        wallets = new HashMap<String, FixedPointNumber>();
    }

    public Map<String, FixedPointNumber> getWallets()
    {
        return wallets;
    }
}
