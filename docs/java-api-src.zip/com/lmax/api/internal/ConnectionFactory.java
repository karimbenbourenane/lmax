package com.lmax.api.internal;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

import com.lmax.api.LmaxApi;

public class ConnectionFactory
{
    private final String urlBase;
    private final String sessionCookie;
    private final String userAgent;

    public ConnectionFactory(final String urlBase)
    {
        this(urlBase, null, null);
    }

    public ConnectionFactory(final String urlBase, final String clientIdentifier)
    {
        this(urlBase, clientIdentifier, null);
    }

    ConnectionFactory(final String urlBase, final String clientIdentifier, final String sessionCookie)
    {
        this.urlBase = urlBase;
        this.sessionCookie = sessionCookie;
        this.userAgent = createUserAgent(clientIdentifier);
    }

    public HttpURLConnection createPostConnection(final Request request) throws IOException
    {
        final URL url = new URL(urlBase + request.getUri());
        final HttpURLConnection conn = createConnection(url);
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Accept", "text/xml");
        conn.setRequestProperty("Content-Type", "text/xml; UTF-8");
        return conn;
    }

    public HttpURLConnection createGetConnection(final Request request) throws IOException
    {
        final URL url = new URL(urlBase + request.getUri());
        final HttpURLConnection conn = createConnection(url);
        conn.setRequestMethod("GET");
        conn.setRequestProperty("Accept", "text/xml");
        return conn;
    }

    public HttpURLConnection createConnection(final URL url) throws IOException
    {
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setDoInput(true);
        conn.setDoOutput(true);
        conn.setUseCaches(false);
        conn.setRequestProperty("Accept", "*/*");
        conn.addRequestProperty("User-Agent", userAgent);

        if (sessionCookie != null)
        {
            conn.addRequestProperty("Cookie", sessionCookie);
        }

        return conn;
    }

    private String createUserAgent(final String connectionIdentifier)
    {
        StringBuilder userAgentBuilder = new StringBuilder("LMAX Java API ");
        userAgentBuilder.append(LmaxApi.PROTOCOL_VERSION);
        if (connectionIdentifier != null && !connectionIdentifier.trim().equals(""))
        {
            userAgentBuilder.append(" ").append(connectionIdentifier.substring(0, Math.min(25, connectionIdentifier.length())));
        }
        return userAgentBuilder.toString();
    }
}
