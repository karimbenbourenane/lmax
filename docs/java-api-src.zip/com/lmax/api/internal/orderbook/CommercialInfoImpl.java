package com.lmax.api.internal.orderbook;

import com.lmax.api.FixedPointNumber;
import com.lmax.api.orderbook.CommercialInfo;

public class CommercialInfoImpl implements CommercialInfo
{
    private final FixedPointNumber minimumCommission;
    private final FixedPointNumber aggressiveCommissionRate;
    private final FixedPointNumber passiveCommissionRate;
    private final FixedPointNumber aggressiveCommissionPerContract;
    private final FixedPointNumber passiveCommissionPerContract;
    private final String fundingBaseRate;
    private final int dailyInterestRateBasis;
    private final FixedPointNumber fundingRate;

    public CommercialInfoImpl(final FixedPointNumber minimumCommission, final FixedPointNumber aggressiveCommissionRate, final FixedPointNumber passiveCommissionRate,
                              final FixedPointNumber aggressiveCommissionPerContract, final FixedPointNumber passiveCommissionPerContract,
                              final String fundingBaseRate, final int dailyInterestRateBasis, final FixedPointNumber fundingRate)
    {
        this.minimumCommission = minimumCommission;
        this.aggressiveCommissionRate = aggressiveCommissionRate;
        this.passiveCommissionRate = passiveCommissionRate;
        this.aggressiveCommissionPerContract = aggressiveCommissionPerContract;
        this.passiveCommissionPerContract = passiveCommissionPerContract;
        this.fundingBaseRate = fundingBaseRate;
        this.dailyInterestRateBasis = dailyInterestRateBasis;
        this.fundingRate = fundingRate;
    }

    @Override
    public FixedPointNumber getMinimumCommission()
    {
        return minimumCommission;
    }

    @Override
    public FixedPointNumber getAggressiveCommissionRate()
    {
        return aggressiveCommissionRate;
    }

    @Override
    public FixedPointNumber getPassiveCommissionRate()
    {
        return passiveCommissionRate;
    }

    @Override
    public FixedPointNumber getAggressiveCommissionPerContract()
    {
        return aggressiveCommissionPerContract;
    }

    @Override
    public FixedPointNumber getPassiveCommissionPerContract()
    {
        return passiveCommissionPerContract;
    }

    @Override
    public String getFundingBaseRate()
    {
        return fundingBaseRate;
    }

    @Override
    public int getDailyInterestRateBasis()
    {
        return dailyInterestRateBasis;
    }

    @Override
    public FixedPointNumber getFundingRate()
    {
        return fundingRate;
    }

    @Override
    public String toString()
    {
        return "CommercialInfo{" +
               "minimumCommission=" + minimumCommission +
               ", aggressiveCommissionRate=" + aggressiveCommissionRate +
               ", passiveCommissionRate=" + passiveCommissionRate +
               ", aggressiveCommissionPerContract=" + aggressiveCommissionPerContract +
               ", passiveCommissionPerContract=" + passiveCommissionPerContract +
               ", fundingBaseRate='" + fundingBaseRate + '\'' +
               ", dailyInterestRateBasis=" + dailyInterestRateBasis +
               ", fundingRate=" + fundingRate +
               '}';
    }

    @Override
    public boolean equals(final Object o)
    {
        if (this == o)
        { return true; }
        if (o == null || getClass() != o.getClass())
        { return false; }

        final CommercialInfoImpl that = (CommercialInfoImpl)o;

        if (dailyInterestRateBasis != that.dailyInterestRateBasis)
        { return false; }
        if (aggressiveCommissionPerContract != null ? !aggressiveCommissionPerContract.equals(that.aggressiveCommissionPerContract) : that.aggressiveCommissionPerContract != null)
        { return false; }
        if (aggressiveCommissionRate != null ? !aggressiveCommissionRate.equals(that.aggressiveCommissionRate) : that.aggressiveCommissionRate != null)
        { return false; }
        if (fundingBaseRate != null ? !fundingBaseRate.equals(that.fundingBaseRate) : that.fundingBaseRate != null)
        { return false; }
        if (fundingRate != null ? !fundingRate.equals(that.fundingRate) : that.fundingRate != null)
        { return false; }
        if (minimumCommission != null ? !minimumCommission.equals(that.minimumCommission) : that.minimumCommission != null)
        { return false; }
        if (passiveCommissionPerContract != null ? !passiveCommissionPerContract.equals(that.passiveCommissionPerContract) : that.passiveCommissionPerContract != null)
        { return false; }
        if (passiveCommissionRate != null ? !passiveCommissionRate.equals(that.passiveCommissionRate) : that.passiveCommissionRate != null)
        { return false; }

        return true;
    }

    @Override
    public int hashCode()
    {
        int result = minimumCommission != null ? minimumCommission.hashCode() : 0;
        result = 31 * result + (aggressiveCommissionRate != null ? aggressiveCommissionRate.hashCode() : 0);
        result = 31 * result + (passiveCommissionRate != null ? passiveCommissionRate.hashCode() : 0);
        result = 31 * result + (aggressiveCommissionPerContract != null ? aggressiveCommissionPerContract.hashCode() : 0);
        result = 31 * result + (passiveCommissionPerContract != null ? passiveCommissionPerContract.hashCode() : 0);
        result = 31 * result + (fundingBaseRate != null ? fundingBaseRate.hashCode() : 0);
        result = 31 * result + dailyInterestRateBasis;
        result = 31 * result + (fundingRate != null ? fundingRate.hashCode() : 0);
        return result;
    }
}
