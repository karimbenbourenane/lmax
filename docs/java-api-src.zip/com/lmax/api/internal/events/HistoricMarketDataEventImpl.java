package com.lmax.api.internal.events;

import java.net.URL;
import java.util.List;

import com.lmax.api.orderbook.HistoricMarketDataEvent;

public class HistoricMarketDataEventImpl implements HistoricMarketDataEvent
{
    private final long instructionId;
    private final List<URL> urls;

    public HistoricMarketDataEventImpl(final long instructionId, final List<URL> urls)
    {
        this.instructionId = instructionId;
        this.urls = urls;
    }

    @Override
    public long getInstructionId()
    {
        return instructionId;
    }

    @Override
    public List<URL> getUrls()
    {
        return urls;
    }

    @Override
    public String toString()
    {
        return "HistoricMarketDataEventImpl{" +
               "instructionId=" + instructionId +
               ", urls=" + urls +
               '}';
    }
}
