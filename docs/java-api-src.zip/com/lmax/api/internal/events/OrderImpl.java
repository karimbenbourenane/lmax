package com.lmax.api.internal.events;

import com.lmax.api.FixedPointNumber;

import com.lmax.api.order.Order;
import com.lmax.api.order.OrderType;

public class OrderImpl implements Order
{
    private final long instructionId;
    private final long originalInstructionId;
    private final String orderId;
    private final long instrumentId;
    private final long accountId;
    private final OrderType orderType;
    private final FixedPointNumber quantity;
    private final FixedPointNumber filledQuantity;
    private final FixedPointNumber cancelledQuantity;
    private final FixedPointNumber limitPrice;
    private final FixedPointNumber stopReferencePrice;
    private final FixedPointNumber stopLossOffset;
    private final FixedPointNumber stopProfitOffset;

    public OrderImpl(final long originalInstructionId, final long instructionId, final String orderId, final long instrumentId, final long accountId, final OrderType orderType,
                     final FixedPointNumber quantity, final FixedPointNumber filledQuantity, final FixedPointNumber cancelledQuantity, final FixedPointNumber limitPrice,
                     final FixedPointNumber stopReferencePrice, final FixedPointNumber stopLossOffset, final FixedPointNumber stopProfitOffset)
    {
        this.instructionId = instructionId;
        this.orderId = orderId;
        this.instrumentId = instrumentId;
        this.accountId = accountId;
        this.orderType = orderType;
        this.quantity = quantity;
        this.filledQuantity = filledQuantity;
        this.cancelledQuantity = cancelledQuantity;
        this.limitPrice = limitPrice;
        this.stopReferencePrice = stopReferencePrice;
        this.stopLossOffset = stopLossOffset;
        this.stopProfitOffset = stopProfitOffset;
        this.originalInstructionId = originalInstructionId;
    }

    @Override
    public FixedPointNumber getCancelledQuantity()
    {
        return cancelledQuantity;
    }

    @Override
    public long getInstructionId()
    {
        return instructionId;
    }

    @Override
    public String getOrderId()
    {
        return orderId;
    }

    @Override
    public long getInstrumentId()
    {
        return instrumentId;
    }

    @Override
    public long getAccountId()
    {
        return accountId;
    }

    @Override
    public OrderType getOrderType()
    {
        return orderType;
    }

    @Override
    public FixedPointNumber getQuantity()
    {
        return quantity;
    }

    @Override
    public FixedPointNumber getFilledQuantity()
    {
        return filledQuantity;
    }

    @Override
    public FixedPointNumber getLimitPrice()
    {
        return limitPrice;
    }

    @Override
    public FixedPointNumber getStopReferencePrice()
    {
        return stopReferencePrice;
    }

    @Override
    public FixedPointNumber getStopLossOffset()
    {
        return stopLossOffset;
    }

    @Override
    public FixedPointNumber getStopProfitOffset()
    {
        return stopProfitOffset;
    }

    @Override
    public long getOriginalInstructionId()
    {
        return originalInstructionId;
    }

    @Override
    public String toString()
    {
        final StringBuilder sb = new StringBuilder();
        sb.append("OrderImpl");
        sb.append("{instructionId=").append(instructionId);
        sb.append(", originalInstructionId=").append(originalInstructionId);
        sb.append(", orderId='").append(orderId).append('\'');
        sb.append(", instrumentId=").append(instrumentId);
        sb.append(", accountId=").append(accountId);
        sb.append(", orderType=").append(orderType);
        sb.append(", quantity=").append(quantity);
        sb.append(", filledQuantity=").append(filledQuantity);
        sb.append(", cancelledQuantity=").append(cancelledQuantity);
        sb.append(", limitPrice=").append(limitPrice);
        sb.append(", stopReferencePrice=").append(stopReferencePrice);
        sb.append(", stopLossOffset=").append(stopLossOffset);
        sb.append(", stopProfitOffset=").append(stopProfitOffset);
        sb.append('}');
        return sb.toString();
    }
}
