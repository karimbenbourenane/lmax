package com.lmax.api.heartbeat;

import com.lmax.api.account.AccountSubscriptionRequest;

/**
 * Subscription request to subscribe to heartbeats.
 */
public class HeartbeatSubscriptionRequest extends AccountSubscriptionRequest
{
}
