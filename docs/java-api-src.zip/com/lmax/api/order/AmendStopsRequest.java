package com.lmax.api.order;

import com.lmax.api.FixedPointNumber;
import com.lmax.api.internal.Request;
import com.lmax.api.internal.xml.StructuredWriter;

/**
 * Request to amend stop loss/profit on an existing order.
 */
public class AmendStopsRequest implements Request
{
    private static final String STOP_LOSS_OFFSET_TAG_NAME = "stopLossOffset";
    private static final String STOP_PROFIT_OFFSET_TAG_NAME = "stopProfitOffset";
    
    private final long instrumentId;
    private final long originalInstructionId;
    private final long instructionId;
    private final FixedPointNumber stopLossOffset;
    private final FixedPointNumber stopProfitOffset;

    /**
     * Construct an AmendStopLossProfitRequest using the instrument id and the instruction id
     * of the original order.
     *
     * @param instrumentId          The instrument id that the original order was placed on.
     * @param originalInstructionId The instructionId id that the original order.
     * @param instructionId         The user-defined correlation ID of the amend stops request
     * @param stopLossOffset        The new stop loss offset, use null to indicate the value should be removed.
     * @param stopProfitOffset      The new stop profit offset, use null to indicate the value should be removed.
     */
    public AmendStopsRequest(final long instrumentId, final long originalInstructionId, final long instructionId, final FixedPointNumber stopLossOffset, final FixedPointNumber stopProfitOffset)
    {
        this.instrumentId = instrumentId;
        this.originalInstructionId = originalInstructionId;
        this.instructionId = instructionId;
        this.stopLossOffset = stopLossOffset;
        this.stopProfitOffset = stopProfitOffset;
    }

    /**
     * Construct an AmendStopLossProfitRequest using the instrument id and the instruction id
     * of the original order.
     *
     * @param instrumentId          The instrument id that the original order was placed on.
     * @param originalInstructionId The instructionId id that the original order.
     * @param stopLossOffset        The new stop loss offset, use null to indicate the value should be removed.
     * @param stopProfitOffset      The new stop profit offset, use null to indicate the value should be removed.
     */
    public AmendStopsRequest(final long instrumentId, final long originalInstructionId, final FixedPointNumber stopLossOffset, final FixedPointNumber stopProfitOffset)
    {
        this(instrumentId, originalInstructionId, 0, stopLossOffset, stopProfitOffset);
    }

    /**
     * The amend stops uri.
     *
     * @return the amend stops uri
     */
    @Override
    public String getUri()
    {
        return "/secure/trade/amendOrder";
    }

    /**
     * Internal: Output this request.
     * 
     * @param writer The destination for the content of this request
     */
    public void writeTo(StructuredWriter writer)
    {
        writer.startElement("req").
                   startElement("body").
                       value("instrumentId", instrumentId).
                       value("originalInstructionId", originalInstructionId).
                       valueOrNone("instructionId", instructionId, 0).
                       value(STOP_LOSS_OFFSET_TAG_NAME, stopLossOffset).
                       value(STOP_PROFIT_OFFSET_TAG_NAME, stopProfitOffset).
                   endElement("body").
               endElement("req");
    }
}
