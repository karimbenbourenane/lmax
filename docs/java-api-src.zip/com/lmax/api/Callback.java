package com.lmax.api;

/**
 * Notifies the success or failure of the Request.
 */
public interface Callback
{
    /**
     * Called when the session was successfully logged out.
     */
    void onSuccess();

    /**
     * Called when a logout failed for any reason.
     *
     * @param failureResponse information on the failure
     */
    void onFailure(FailureResponse failureResponse);
}
